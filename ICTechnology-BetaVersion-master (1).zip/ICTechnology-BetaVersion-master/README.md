# ICTechnology
<P>
Install
<P>
1.Download [Minecraft Forge 3.4.9.171](http://files.minecraftforge.net/maven/net/minecraftforge/forge/index_1.2.5.html)
<P>
2.Download [OptiFine 1.2.5 HD U C7](http://adf.ly/404181/optifine.net/adloadx.php?f=OptiFine_1.2.5_HD_U_C7.zip)
<P>
3.Download [Minecraft API(Japanese)](http://minecraft125user.nisfan.net/forum/viewtopic.php?f=11&t=133&sid=00054328ae0a227b09cd7d0f3489d94b)
<P>
4.Download [IndustrialCraft2](http://forum.industrial-craft.net/index.php?page=Thread&threadID=5896)
<P>
5.Download [ICTecnology]
<P>
6.Install Minecraft Forge 3.4.9.171
<P>
7.Install OptiFine_1.2.5_HD_U_C7
<P>
8.Install Minecraft API
<P>
9.Install IndustrialCraft2
<P>
10.Install ICTecnology
<P>
11.Play Minecraft 1.2.5
